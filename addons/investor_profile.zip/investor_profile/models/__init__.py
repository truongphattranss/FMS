from . import investor_profile
from . import investor_bank_account
from . import investor_address
from . import res_partner
from . import status_info
